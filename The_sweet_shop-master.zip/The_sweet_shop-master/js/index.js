function cart()
{  
    var x = document.getElementById("cartNo").textContent;
    var y= parseInt(x);
    z=(y+1);
    alert(z); 
    document.getElementById("")  
}
